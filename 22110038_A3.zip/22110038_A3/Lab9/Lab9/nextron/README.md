<img src="https://i.imgur.com/yUhptaN.png" />

[![Available on SpigotMC](https://raw.githubusercontent.com/vLuckyyy/badges/main/available-on-spigotmc.svg)](https://www.spigotmc.org/resources/nextron.106476/)
[![Available on Modrinth](https://raw.githubusercontent.com/vLuckyyy/badges/main/avaiable-on-modrinth.svg)](https://modrinth.com/plugin/nextron)
[![Available on Hangar](https://raw.githubusercontent.com/vLuckyyy/badges/main/avaiable-on-hangar.svg)](https://hangar.papermc.io/PandaDEV/Nextron)
<br>[![Chat on Discord](https://raw.githubusercontent.com/vLuckyyy/badges/main//chat-with-us-on-discord.svg)](https://discord.gg/invite/Y7SbYphVw9)
[![Available on BStats](https://raw.githubusercontent.com/vLuckyyy/badges/main/available-on-bstats.svg)](https://bstats.org/plugin/bukkit/Nextron/20704)

[Website >](https://nextron.pandadev.net?q=modrinth)

<a href="https://buymeacoffee.com/pandadev_"><img src="https://img.shields.io/badge/Buy_Me_A_Coffee-FFDD00?style=for-the-badge&logo=buy-me-a-coffee&logoColor=black"/></a>

<br>

<img src="https://i.imgur.com/Dmsuye5.png" height="54px"/>

Nextron is a powerful Minecraft plugin which is meant to replace any other plugins you use at the moment. It has
beautiful GUI's that simplifies the process to many users because you don't have to use complicated commands.

<br>

<img src="https://i.imgur.com/Bpfp6b4.png" height="54px"/>

- A permission plugin is highly recommended, for example [LuckPerms](https://luckperms.net/), as it can manage all
  permissions.
- Nextron runs on Bukkit, Spigot, Paper and [Purpur (recommended)](https://purpurmc.org/).
- Nextron supports 1.13 and higher.

<br>

<img src="https://i.imgur.com/0kxCPzO.png" height="54px"/>

If you have any issues or find a bug, please remember to report it
here [GitHub](https://github.com/0PandaDEV/Nextron/issues)

<br>

<img src="https://i.imgur.com/YfDo4AW.png" height="54px"/>

[anvilgui](https://github.com/WesJD/AnvilGUI) by WesJD <br>
[triumph-gui](https://github.com/TriumphTeam/triumph-gui) by triumph team <br>
[languify](https://github.com/Hekates/Languify) by Hekates

***

Check out my other projects on [my profile](https://modrinth.com/user/PandaDEV)
