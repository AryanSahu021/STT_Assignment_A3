-- Insert default value for chat_formatting_system
INSERT INTO features (name, state) VALUES ('chat_formatting_system', TRUE);
