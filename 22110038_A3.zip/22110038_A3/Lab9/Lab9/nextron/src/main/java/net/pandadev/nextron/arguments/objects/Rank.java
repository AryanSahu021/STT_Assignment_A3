package net.pandadev.nextron.arguments.objects;

import lombok.Getter;

@Getter
public class Rank {
    // Getter
    private final String name;

    public Rank(String name) {
        this.name = name;
    }

}
