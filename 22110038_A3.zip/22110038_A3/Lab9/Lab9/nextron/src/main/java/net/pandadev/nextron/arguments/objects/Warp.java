package net.pandadev.nextron.arguments.objects;

import lombok.Getter;

@Getter
public class Warp {
    private final String name;

    public Warp(String name) {
        this.name = name;
    }

}
