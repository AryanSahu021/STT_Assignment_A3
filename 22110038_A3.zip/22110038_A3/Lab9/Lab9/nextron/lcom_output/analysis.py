import pandas as pd

# Load LCOM results from CSV file
csv_file = "TypeMetrics.csv"  # Change to your actual file path
df = pd.read_csv(csv_file)

# Define LCOM threshold (adjust as needed)
lcom_threshold = 3.0  # Extract classes with any LCOM metric above this value

# Identify high-LCOM classes
high_lcom_classes = df[
    (df["LCOM1"] > lcom_threshold) |
    (df["LCOM2"] > lcom_threshold) |
    (df["LCOM3"] > lcom_threshold) |
    (df["LCOM4"] > lcom_threshold) |
    (df["LCOM5"] > lcom_threshold) |
    (df["YALCOM"] > lcom_threshold)
]

# Display extracted high-LCOM classes
print("Classes with High LCOM Values:")
print(high_lcom_classes)

# Save to a new CSV file for further analysis
output_file = "high_lcom_classes.csv"
high_lcom_classes.to_csv(output_file, index=False)
print(f"High LCOM classes saved to {output_file}")
