import json
import pprint
# Load the dependencies.json file
with open("dependencies.json", "r") as f:
    data = json.load(f)

fan_in = {}
fan_out = {}

# Compute fan-in and fan-out
for module, deps in data.items():
    fan_out[module] = len(deps)
    for dep in deps:
        if dep not in fan_in:
            fan_in[dep] = 0
        fan_in[dep] += 1

# Print results
print("Module Fan-In:")
pprint.pprint(fan_in)
print("Module Fan-Out:")
pprint.pprint(fan_out)
