from .te_llama import TELlamaModel
